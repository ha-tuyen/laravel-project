@extends('admin.layout.app')
@section('content')
<p>đây là content</p>
@stop