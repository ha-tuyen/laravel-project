
    <div class="container">
    <div class="row">
        <div class="col-12">
            <div class="section-title">
                <h2>Sản phẩm bán chạy</h2>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="owl-carousel popular-slider">
                <!-- Start Single Product -->
                <div class="single-product">
                    <div class="product-img">
                        <a href="product-details.html">
                            <img class="default-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <img class="hover-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <span class="out-of-stock">Hot</span>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a data-toggle="modal" data-target="#exampleModal" title="Xem chi tiết" href="#"><i class=" ti-eye"></i><span>Xem chi tiết</span></a>
                                <a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to Wishlist</span></a>
                                <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Thêm giỏ hàng" href="#">Thêm giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="product-details.html">Black Sunglass For Women</a></h3>
                        <div class="product-price">
                            <span class="old">$60.00</span>
                            <span>$50.00</span>
                        </div>
                    </div>
                </div>
                <!-- End Single Product -->
                <!-- Start Single Product -->
                <div class="single-product">
                    <div class="product-img">
                        <a href="product-details.html">
                            <img class="default-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <img class="hover-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a data-toggle="modal" data-target="#exampleModal" title="Xem chi tiết" href="#"><i class=" ti-eye"></i><span>Xem chi tiết</span></a>
                                <a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to Wishlist</span></a>
                                <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Thêm giỏ hàng" href="#">Thêm giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="product-details.html">Women Hot Collection</a></h3>
                        <div class="product-price">
                            <span>$50.00</span>
                        </div>
                    </div>
                </div>
                <!-- End Single Product -->
                <!-- Start Single Product -->
                <div class="single-product">
                    <div class="product-img">
                        <a href="product-details.html">
                            <img class="default-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <img class="hover-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <span class="new">New</span>
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a data-toggle="modal" data-target="#exampleModal" title="Xem chi tiết" href="#"><i class=" ti-eye"></i><span>Xem chi tiết</span></a>
                                <a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to Wishlist</span></a>
                                <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Thêm giỏ hàng" href="#">Thêm giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="product-details.html">Awesome Pink Show</a></h3>
                        <div class="product-price">
                            <span>$50.00</span>
                        </div>
                    </div>
                </div>
                <!-- End Single Product -->
                <!-- Start Single Product -->
                <div class="single-product">
                    <div class="product-img">
                        <a href="product-details.html">
                            <img class="default-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                            <img class="hover-img" src="{{ asset('home/images/sp1.jpg') }}" alt="#">
                        </a>
                        <div class="button-head">
                            <div class="product-action">
                                <a data-toggle="modal" data-target="#exampleModal" title="Xem chi tiết" href="#"><i class=" ti-eye"></i><span>Xem chi tiết</span></a>
                                <a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to Wishlist</span></a>
                                <a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to Compare</span></a>
                            </div>
                            <div class="product-action-2">
                                <a title="Thêm giỏ hàng" href="#">Thêm giỏ hàng</a>
                            </div>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="product-details.html">Awesome Bags Collection</a></h3>
                        <div class="product-price">
                            <span>$50.00</span>
                        </div>
                    </div>
                </div>
                <!-- End Single Product -->
            </div>
        </div>
    </div>
    </div>
