<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Category;
class CategorysController extends Controller
{
    public function index() {
        $category = Category::with('parent')->paginate(10);
        return view('admin.categorys.index', ['category' => $category]);
    }
}
