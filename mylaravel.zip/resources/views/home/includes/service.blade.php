<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-12">
            <!-- Start Single Service -->
            <div class="single-service">
                <i class="ti-rocket"></i>
                <h4>Miễn phí ship</h4>
                <p>Cho đơn hàng từ 500k</p>
            </div>
            <!-- End Single Service -->
        </div>
        <div class="col-lg-3 col-md-6 col-12">
            <!-- Start Single Service -->
            <div class="single-service">
                <i class="ti-reload"></i>
                <h4>Trả lại miễn phí</h4>
                <p>Trong vòng 30 ngày</p>
            </div>
            <!-- End Single Service -->
        </div>
        <div class="col-lg-3 col-md-6 col-12">
            <!-- Start Single Service -->
            <div class="single-service">
                <i class="ti-lock"></i>
                <h4>Thanh toán an toàn</h4>
                <p>Thanh toán an toàn 100%</p>
            </div>
            <!-- End Single Service -->
        </div>
        <div class="col-lg-3 col-md-6 col-12">
            <!-- Start Single Service -->
            <div class="single-service">
                <i class="ti-tag"></i>
                <h4>Giá tốt</h4>
                <p>Đảm bảo</p>
            </div>
            <!-- End Single Service -->
        </div>
    </div>
</div>